import java.io.File;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Color;

public class Mandelbrot{
public static void main(String[] args)throws Exception{
int width=1920,height=1080,max=100;
int balck=0x000000,white=0xFFFFFF;
BufferedImage image= new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);

for(int row=0;row<height;row++){
	for(int col=0;col<width;col++){
		double x=0,y=0;
		double i=(row-height/2)*4.0/width;
		double j=(col-width/2)*4.0/width;
		int iterations=0;
		
		while(iterations<max && x*x+y*y<4){
			double x_new=x*x-y*y+j;
				y=2*x*y+i;
				x=x_new;
				iterations++;			
				}
	float sat=1f;
	float brightness=iterations<max?1f:0;
        float hue=(iterations%256)/255.0F;
	   image.setRGB(col, row, Color.getHSBColor(hue, sat, brightness).getRGB());
		if(iterations<max) image.setRGB(col,row,Color.getHSBColor(hue,sat,brightness).getRGB());
		else image.setRGB(col,row,balck);
			}
		}
	ImageIO.write(image,"png",new File("mandelbrot.png"));	
	}
}
