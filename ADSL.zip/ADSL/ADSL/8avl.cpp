//============================================================================
// Name        : assignment8.cpp
// Author      : saurabh
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include<iostream>
#include<string>
using namespace std;
class dictionary;
class avlnode{
	string keyword,meaning;
	avlnode *left;
	avlnode *right;
	int bf;
public:
	avlnode(){
		keyword = '\0';
		meaning = '\0';
		left = right = NULL;
		bf = 0;
	}
	avlnode(string k,string m){
		keyword = k;
		meaning = m;
		left = right = NULL;
		bf = 0;
	}
	friend class dictionary;
};
class dictionary
{
	avlnode *par,*loc;
public:
	avlnode *root;
	dictionary(){
		root = NULL;
		par = loc = NULL;
	}
	void accept();
	void insert(string key,string mean);
	void LLrotation(avlnode*, avlnode*);
	void RRrotation(avlnode*,avlnode*);
	void inorder(avlnode *);
	void descending(avlnode *);
	void search(string);
	void update(string, string);
};
void dictionary::accept(){
	string key,mean;
	cin.clear();
	cout<<"\nenter the key\n";
	cin>>key;
	cout<<"\nenter the meaning";
	cin>>mean;
	insert(key,mean);
}
void dictionary::LLrotation(avlnode *a,avlnode *b){
	cout<<"LLrotation"<<endl;
	a->left = b->right;
	b->right = a;
	a->bf = b->bf = 0;
}
void dictionary::RRrotation(avlnode *a,avlnode *b){
	cout<<"\nRRrotation"<<endl;
	a->right = b->left;
	b->left = a;
	a->bf = b->bf = 0;
}
void dictionary::insert(string key,string mean){
	if(!root){
		root = new avlnode(key,mean);
		cout<<"\nROOT CREATION\n";
		return;
	}
	avlnode *a,*pa,*p,*pp;
	pa = NULL;
	p = a = root;
	pp = NULL;
	while(p){
		cout<<"\nin first while";
		if(p->bf){
			a = p;
			pa = pp;
		}
		if(key < p->keyword){
			pp = p;
			p = p->left;
		}
		else if(key > p->keyword){
			pp = p;
			p = p->right;
		}
		else {
			cout<<"\nAlready exists";
			return;
		}
	}
	cout<<"\noutside while"<<endl;
	avlnode *y = new avlnode(key,mean);
	if(key < pp->keyword){
		pp->left = y;
	}
	else
		pp->right = y;
	cout<<"\nKEY INSERTED\n";

	int d;
	avlnode *b,*c;
	b = c = NULL;
	if(key > a->keyword){
		cout<<"KEY > A -> KEYWORD"<<endl;
		b = p = a->right;
		d = -1;
		cout<<"\nRIGHT HEAVY"<<endl;
	}
	else{
		cout<<"KEY<A->KEYWORD"<<endl;
		b = p = a->left;
		d = 1;
		cout<<"\nLEFT HEAVY\n";
	}
	while(p!=y){
		if(key > a->keyword){
			p->bf = -1;
			p = p->right;
		}
		else{
			p->bf = 1;
			p = p->left;
		}
	}
	cout<<"DONE ADJUSTING INTERNAL NODE"<<endl;
	if(!(a->bf) || !(a->bf+d)){
		a->bf += d;
		return;
	}
	if(d == 1){
		if(b->bf == 1){
			cout<<"\nLLrotation"<<endl;
			LLrotation(a,b);
		}
		else{
			cout<<"\nLR rotation"<<endl;
			c = b->right;
			b->right = c->left;
			a->left = c->right;
			c->left = b;
			c->right = a;
			switch(c->bf){
			case 1:
			{
				a->bf = -1;
				b->bf = 0;
				break;
			}
			case -1:
			{
				a->bf = 0;
				b->bf = 1;
				break;
			}
			case 0:
			{
				a->bf = 0;
				b->bf = 0;
				break;
			}
			}
			c->bf = 0;
			b = c;      //b is new root....
		}
	}
	if(d == -1){
		if(b->bf == -1){
			cout<<"\nRRrotation..\n";
			RRrotation(a, b);
		}
		else{
			c = b->left;
			cout<<"\nRL rotation\n";
			a->right = c->left;
			b->left = c->right;
			c->left =a;
			c->right = b;
			switch(c->bf){
			case 1:
			{
				a->bf = 0;
				b->bf = -1;
				break;
			}
			case -1:
			{
				a->bf = 1;
				b->bf = 0;
				break;
			}
			case 0:
			{
				a->bf = 0;
				b->bf = 0;
				break;
			}
			}
			c->bf = 0;
			b = c;
		}
	}

	if(!pa)
		root = b;
	else if(a == pa->left)
			pa->left = b;
	else
		pa->right = b;
	cout<<"AVL TREE ADJUSTED";
}
void dictionary::search(string key){
	cout<<"\nENTER SEARCH\n";
	loc = NULL;
	par = NULL;
	if(root == NULL){
		cout<<"\nTree is not created"<<endl;
		loc = NULL;
		par = NULL;
	}
	avlnode *ptr;
	ptr = root;
	while(ptr != NULL){
		if(ptr->keyword == key){
			loc = ptr;
			break;
		}
		else if(key < ptr->keyword){
			par = ptr;
			ptr = ptr->left;
		}
		else{
			par = ptr;
			ptr = ptr->right;
		}
	}
	if(loc == NULL)
		cout<<"\nNot found";
}
void dictionary::inorder(avlnode *start){
	if(start == NULL)
		return;
	inorder(start->left);
	cout<<start->keyword<<"\t"<<start->meaning<<endl;
	inorder(start->right);
}
void dictionary::update(string oldkey,string newmean){
	search(oldkey);
	if(!loc)
		return;
	else
		loc->meaning = newmean;
	cout<<"\nMEAN IS UPDATED";
}
void dictionary::descending(avlnode *start){
	if(start == NULL)
		return;
	inorder(start->right);
	cout<<start->keyword<<"\t"<<start->meaning<<endl;
	inorder(start->left);
}
int main(){
	string k,m;
	dictionary d;
	int ch;
	do {
		cout<<"\n1.Insert\n2.Update\n3.Ascending\n4.descending";
		cin>>ch;
		switch(ch){
		case 1:
		{
			d.accept();
			break;
		}
		case 2:
		{
			cin.clear();
			cout<<"\nEnter the key whose mean is updated an  new mean";
			cin>>k>>m;
			d.update(k,m);
			break;

		}
		case 3:
		{
			d.inorder(d.root);
			break;
		}
		case 4:
		{
			d.descending(d.root);
			break;
		}
	}

	}while(ch != 6);
	return 0;
}
