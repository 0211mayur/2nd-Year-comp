#include <iostream>
#include <string.h>
#include <sstream>
#include <math.h>
using namespace std;
int cnt;
class node{

	int data;
	node *lchild,*rchild;
public:
	friend class tree;
	friend class stack;
	node(int x){
		data=x;
		lchild=NULL;
		rchild=NULL;
	}
};
class stack{
public:
	int top;
	node *arr[20];
	stack(){
		top=-1;
	}
	void push(node *x){
		top++;
		arr[top]=x;
	}
	node* pop(){
		if(!empty()){
			node *q;
			q=arr[top];
			top--;
			return q;
		}
	}
	bool empty(){
		if(top==-1)return 1;
		return 0;
	}
	int tops(){
		node *p;
		p=arr[top];
		return p->data;
	}
};
class tree{


	int top;
public:
	node *root;
	tree(){
		root=NULL;
		top=-1;
	}

	void create(int x){

		node *p;
		p=new node(x);
		root=p;
	}
	void insert(string s,int x){

		node *p,*q,*r;
		r=new node(x);
		int flag=1;
		p=root;q=root;
		int i=0;
		int z=s.length()-1;
		while(i<=z){
			if((s[i]!='0')&&(s[i]!='1')){
				cout<<"Invalid Input\n";
				flag=0;
				break;
			}
			++i;
		}
		if(flag==1){
			i=0;
			while(i<z){
				if(!q){
					cout<<"Tree not available\n";
					goto label;


				}
				else {
					if(s[i]=='0')q=q->lchild;
					else q=q->rchild;
				}
				++i;
			}

			//if(q->lchild || q->rchild)cout<<"false\n";

			if(!q){
				cout<<"Tree not available\n";
				goto label;
			}


			else{
				if(s[i]=='0')q->lchild=r;
				else q->rchild=r;

				inorder(p);
			}
		}
		label:cout<<"";


	}
	node *nod(){
		return root;
	}

	void inorder(node *t){
		if(t!=NULL){
			inorder(t->lchild);
			cout<<t->data<<" ";
			inorder(t->rchild);
		}
		//cout<<"\n";
	}
	void preorder(node *t){
		if(t!=NULL){
			cout<<t->data<<" ";
			preorder(t->lchild);
			preorder(t->rchild);
		}
		//cout<<"\n";
	}
	void postorder(node *t){
		if(t!=NULL){

			postorder(t->lchild);
			postorder(t->rchild);
			cout<<t->data<<" ";
		}
	}
	void innon(node *t){
		stack s;
		while(1){
			while(t!=NULL){
				s.push(t);
				t=t->lchild;
			}
			if(s.empty())return;
			t=s.pop();
			cout<<t->data<<" ";
			t=t->rchild;
		}
	}
	void prenon(node *t){
		stack s;
		while(1){
			while(t!=NULL){
				cout<<t->data<<" ";
				s.push(t);
				t=t->lchild;
			}
			if(s.empty())return;
			t=s.pop();
			t=t->rchild;
		}
	}
	void postnon(node *t){
		stack s;
		node *p;
		p=new node(-1);
		while(1){

			while(t!=NULL){
				s.push(t);
				if(t->rchild!=NULL){
					s.push(t->rchild);
					s.push(p);
				}
				t=t->lchild;
			}
			if(s.empty())return;
			t=s.pop();
			while((p!=t) && (!s.empty())){

				cout<<t->data<<" ";
				t=s.pop();
			}
			if(!s.empty())t=s.pop();
		}
	}
	tree operator =(tree val){
		tree obj;
		obj.root=assign(val.root);
		return obj;
	}
	node *assign(node *t){
		if(t==NULL)return NULL;
		node *m=new node(t->data);
		m->lchild=assign(t->lchild);
		m->rchild=assign(t->rchild);
		return m;
	}
	node *mirror(node *t){
		if(t==NULL)return NULL;
		node *m=new node(t->data);
		m->lchild=mirror(t->rchild);
		m->rchild=mirror(t->lchild);
		return m;
	}
	int height(node *t){
		if((t==NULL) || ((t->lchild==NULL) && (t->rchild==NULL)))return 0;
		else{
			int h1=height(t->lchild);
			int h2=height(t->rchild);
			if(h1>h2)return(h1+1);
			else return(h2+1);

		}
	}
	void leafnodes(node *t){
	   if(t!=NULL)
	   {
		  if((t->lchild==NULL)&&(t->rchild==NULL)){
			  //cout<<t->data<<" ";
			  cnt++;
			  return;
		  }

		  else{
				leafnodes(t->lchild);
				leafnodes(t->rchild);
				return;
			}
	   }
	}
	void erase(node *t){
		if(t==NULL)return;
		erase(t->lchild);
		erase(t->rchild);
		cout<<"Deleted Node : "<<t->data<<"\n";
		delete t;
	}

};
int check(string str){

	int len=str.length();
	int z=pow(2,64);
	if(len>z)return 0;
	for(int i=0;i<str.length();i++){
		if((int(str[i])>=48) && (int(str[i])<=57))continue;
		else return 0;
	}
	return 1;
}
int check1(string str){
	int len=str.length();
	if(len>6)return 0;
	for(int i=0;i<str.length();i++){
			if((int(str[i])>=48) && (int(str[i])<=57))continue;
			else return 0;
		}
	return 1;
}
int check2(string str){
	int len=str.length();
	if(len>2)return 0;
	if(len==1){
		if(int(str[0]>48) && int(str[0]<=57))return (int(str[0])-48);
		else return 0;
	}
	if(len==2){
		if(str[0]=='1' && str[1]=='0')return 10;
		else if(str[0]=='1' && str[1]=='1')return 11;
		else if(str[0]=='1' && str[1]=='2')return 12;
		else return 0;
	}
	return 0;
}
int main() {

	tree t;
	string str;
	string n;
	string d;
	label:cout<<"Enter the number of nodes\n";
	cin>>d;
	if(!check(d)){cout<<"Invalid input\n";goto label;}

	cout<<"Enter the data of root node\n";
	cin>>n;
	if(!check1(n)){cout<<"Invalid input\n";goto label;}
	int x=0;
	stringstream shreyans(n);
	shreyans>>x;
	t.create(x);
	int i=0;
	int g;
	stringstream sh(d);
	sh>>g;
	int z=g-1;
	while(i<z){
		label1:cout<<"\nEnter the path and data\n";
		cin>>str;
		cin>>n;
		if(!check1(n)){cout<<"Invalid input\n";goto label1;}
		x=0;
		stringstream shreyans(n);
		shreyans>>x;
		t.insert(str,x);
		++i;

	}
	string v;int h;string f;
	f='y';
	cout<<"\n\nTree is created\n\n";
	//t.postnon(t.nod());
	while(f=="y" || f=="Y"){
	label2:cout<<"Enter you choice\n\n1.inorder recursive\n2.preorder recursive\n3.postorder recursive\n4.inorder nonrecursive\n5.preorder nonrecursive\n6.postorder nonrecursive\n7.mirror\n8.height\n9.erase\n10.copy tree\n11.leafnodes\n12.internal nodes\n";
	string q;
	cin>>q;
	h=check2(q);
	//if(h==0)cout<<"Invalid input\n";
	if(h==1){
		t.inorder(t.nod());cout<<"\n";}
	else if(h==2){
		t.preorder(t.nod());cout<<"\n";}
	else if(h==3){
		t.postorder(t.nod());cout<<"\n";}
	else if(h==4){
		t.innon(t.nod());cout<<"\n";}
	else if(h==5){
		t.prenon(t.nod());cout<<"\n";}
	else if(h==6){
		t.postnon(t.nod());cout<<"\n";}
	else if(h==7){
		node *p=t.mirror(t.nod());
		t.inorder(p);
		cout<<"\n";}
	else if(h==8){
		cout<<t.height(t.nod())<<"\n";}
	else if(h==9){
		t.erase(t.nod());
		cout<<"\n";}
	else if(h==10){
		tree t1=t;
		t1.inorder(t1.nod());
	}
	else if(h==11){
		cnt=0;
		t.leafnodes(t.nod());
		cout<<cnt<<"\n";
	}
	else if(h==12){
		cnt=0;
		t.leafnodes(t.nod());
		cout<<g-cnt<<"\n";
	}
	else {
		cout<<"Invalid input\n";
		goto label2;
	}
	label3:cout<<"Do you want to continue(y/n)\n";
	cin>>f;
	if(f!="y" && f!="Y" && f!="n" && f!="N"){cout<<"Enter (y/n)\n";goto label3;}

	}


	return 0;
}



