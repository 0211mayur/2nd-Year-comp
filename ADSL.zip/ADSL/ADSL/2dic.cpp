
#include <iostream>
using namespace std;
int flag,cnt;
class BST;
class node{

public:
	string a,b;
	node *left,*right;
	node(string x,string y){

		a=x;
		b=y;
		left=NULL;
		right=NULL;
	}
	friend class BST;
};
class BST{

public:
	node *root;
	BST(){
		root=NULL;
	}
	void input(){

		int n;
		string str1,str2;
		cout<<"Enter total number of words\n";
		cin>>n;
		cin.ignore();
		cout<<"Enter the word and meaning of root node\n";
		getline(cin,str1);
		getline(cin,str2);
		root=create(root,str1,str2);
		cout<<"Enter the word and meaning for other nodes\n";
		for(int i=0;i<n-1;i++){
			getline(cin,str1);
			getline(cin,str2);
			create(root,str1,str2);
		}
	}
	node *create(node *t,string p,string q){
		if(t==NULL){
			t=new node(p,q);
			return t;
		}
		else{
			if(t->a>p){
				t->left=create(t->left,p,q);
			}
			else{
				t->right=create(t->right,p,q);
			}
			return t;
		}
	}

	void inorder(node *t){
		if(t!=NULL){
				inorder(t->left);
				cout<<t->a<<" : "<<t->b<<"\n";
				inorder(t->right);
			}
	}

	node *mirror(node *t){
		if(t==NULL)return NULL;
		node *m=new node(t->a,t->b);
		m->left=mirror(t->right);
		m->right=mirror(t->left);
		return m;
	}

	void search_inorder(node *t,string item){
		if(t!=NULL && flag==0){
			search_inorder(t->left,item);
			if(t->a==item){
				flag=1;
			}
			else cnt++;
			search_inorder(t->right,item);
		}
		else return;
	}

	void update_inorder(node *t,string key,string update){
		if(t!=NULL && flag==0){
			update_inorder(t->left,key,update);
			if(t->a==key){
				flag=1;
				t->b=update;
			}
			update_inorder(t->right,key,update);
		}
		else return;
	}

	void delete_(string key){
		node *p,*q;
		q=root;
		int falg=0;
		while(q!=NULL)
		{
			if(q->a==key)
			{
				falg=1;
				break;

			}
			if(q->a>key)
			{
				p=q;
				q=q->left;
			}
			else
			{
				p=q;
				q=q->right;
			}
		}
		if(falg==0)cout<<"Word not found !\n";
		else {
			cout<<"Deleted successfully\n";
			if(q->right!=NULL&&q->left!=NULL)
			{
				node *t=p->right;
				while(t->left!=NULL)
				{
					t=t->left;
				}
				p->a=t->a;
				p->b=t->b;
				q=t;
			}
			else if(q->right==NULL&&q->left==NULL)
			{
				if(p->right==q)
				{
					p->right=NULL;

				}
				else
				{
					p->left=NULL;

				}

			}
			else if(q->right==NULL&&q->left!=NULL)
			{
				if(q==p->left)
				{
					p->left=q->left;
				}
				else
				{
					p->right=q->left;
				}
				if(q!=root)
				{
					delete q;

				}

			}
			else if(q->right!=NULL&&q->left==NULL)
			{
				if(q==p->left)
				{
					p->left=q->right;
				}
				else
				{
					p->right=q->right;
				}
				if(q!=root)
				{
					delete q;

				}

			}
		}

	}
};

int main() {

	BST b;
	b.input();
	int h;
	string g;
	do{
		cout<<"\nEnter the choice\n\n1.Dictionary in Ascending order\n2.Dictionary in Descending order\n3.Search a word\n4.Update the dictionary\n5.Delete a word\n";
		cin>>h;
		cin.ignore();

		if(h==1)b.inorder(b.root);
		else if(h==2){
			node *p=b.mirror(b.root);
			b.inorder(p);
		}
		else if(h==3){
			string search;
			flag=0;cnt=0;
			cout<<"Enter a word to be searched\n";
			getline(cin,search);
			b.search_inorder(b.root,search);
			if(flag==1)cout<<"Word found\n";
			else cout<<"Word not found\n";
			cout<<"Number of comparisons : "<<cnt+1<<"\n";
		}
		else if(h==4){
			string u,v;
			flag=0;
			cout<<"Enter the word and its new meaning\n";
			getline(cin,u);
			getline(cin,v);
			b.update_inorder(b.root,u,v);
			if(flag==1){
				cout<<"Updated Successfully !\n\nUpdated dictionary : \n\n";
				b.inorder(b.root);
			}
			else{
				cout<<"Word does not exist \n";
			}
		}
		else if(h==5){
			string u;
			cout<<"Enter the word you want to delete\n";
			getline(cin,u);
			b.delete_(u);
			cout<<"\nDictionary after deletion :\n\n";
			b.inorder(b.root);
		}
		cout<<"Do you want to continue ?(y/n)\n";
		cin>>g;
	}while(g=="y"||g=="Y");
	return 0;
}
