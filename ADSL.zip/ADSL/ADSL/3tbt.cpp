#include <iostream>
#include <string.h>
#include <sstream>
#include <math.h>
using namespace std;
class TBT;
class node
{
 node *left,*right;
 int data;
 bool rbit,lbit;
public:
 node()
{
  left=NULL;
  right=NULL;
  rbit=lbit=0;
}
 node(int d)
 {
  left=NULL;
  right=NULL;
  rbit=lbit=0;
  data=d;
 }
 friend class TBT;
};

class TBT
{
 node *root; //acts as a dummy node
public:
 TBT() //dummy node initialization
{
  root=new node(9999);
  root->left=root;
  root->rbit=1;
  root->lbit=0;
  root->right=root;
}
 void create();
 void insert(int data);
 node *inorder_suc(node *);
 void inorder_traversal();
 node * preorder_suc(node *c);
 void preorder_traversal();
};
//--------------------------------------------
void TBT::preorder_traversal()
{
 node *c=root->left;
 while(c!=root)
 {
  cout<<" "<<c->data;
  c=preorder_suc(c);
 }
}
void TBT::inorder_traversal()
{
 node *c=root->left;
 while(c->lbit==1)
  c=c->left;
 while(c!=root)
 {
  cout<<" "<<c->data;
  c=inorder_suc(c);
 }
}
node* TBT::inorder_suc(node *c)
{
 if(c->rbit==0)
  return c->right;
 else
  c=c->right;
 while(c->lbit==1)
 {
  c=c->left;
 }
 return c;
}
node *TBT::preorder_suc(node *c)
{
 if(c->lbit==1)
 {
  return c->left;
 }
 while(c->rbit==0)
 {
  c=c->right;
 }
 return c->right;
}
//-------- Create Method
void TBT::create()
{
 string nii;
 
 cout<<"\nEnter number of nodes:";
 cin>>nii;
 
 int n;
 stringstream s(nii);
 s>>n;
 for(int i=0;i<n;i++)
 {
  int info;
  cout<<"\nEnter data: ";
  cin>>info;
  this->insert(info);
 }
}
void TBT::insert(int data)
{

 if(root->left==root&&root->right==root) //no node in tree
 {
  node *p=new node(data);
  p->left=root->left;
  p->lbit=root->lbit; //0
  p->rbit=0;
  p->right=root->right;
  root->left=p;
  root->lbit=1;
  cout<<"\nInserted start"<<data;
  return;
 }
 node *cur=new node;
 cur=root->left;
 while(1)
 {

  if(cur->data<data)   //insert right
  {
   node *p=new node(data);
   if(cur->rbit==0)
   {
    p->right=cur->right;
    p->rbit=cur->rbit;
    p->lbit=0;
    p->left=cur;
    cur->rbit=1;
    cur->right=p;
    cout<<"\nInserted right "<<data;
    return;
   }
   else
    cur=cur->right;
  }
  if(cur->data>data) //insert left
  {
   node *p=new node(data);
   if(cur->lbit==0)
   {
    p->left=cur->left;
    p->lbit=cur->lbit;
    p->rbit=0;
    p->right=cur; //successor
    cur->lbit=1;
    cur->left=p;
    cout<<"\nInserted left"<<data;
    return;
   }
   else
    cur=cur->left;
  }
 }

}

int check(string str){
	if(str.length()!=1)return 0;
	if(str[0]!='1' && str[0]!='2' && str[0]!='3' && str[0]!='4' && str[0]!='0')return 0;
	return 1;	
}
int check1(string str){
	int len=str.length();
	if(len>6)return 0;
	for(int i=0;i<str.length();i++){
			if((int(str[i])>=48) && (int(str[i])<=57))continue;
			else return 0;
		}
	return 1;
}
int main() {
 TBT t1;
 string value;
 string choice;
 int intchoice;
  while(1){
  label:cout<<"\n1.Create Tree\n2.Insert into tree\n3.Preorder\n4.Inrder\n0.Exit\nEnter your choice: ";
  cin>>choice;
  if(!check(choice)){cout<<"Invalid input\n";goto label;}
  
  stringstream shrey(choice);
  shrey>>intchoice;
  if(intchoice==1){
	 string nii;
	 label3:
	 cout<<"\nEnter number of nodes:";
	 cin>>nii;
	 if(!check1(nii)){cout<<"Enter valid data\n";goto label3;}
	 int n;
	 stringstream s(nii);
	 s>>n;
	 for(int i=0;i<n;i++)
	 {
	  string info;
	  label4:cout<<"\nEnter data: ";
	  cin>>info;
	  if(!check1(info)){cout<<"Enter valid data\n";goto label4;}
	  stringstream shr(info);
	  int fo;
	  shr>>fo;
	  t1.insert(fo);
	 }
  }
  else if(intchoice==2){
  	label1:
	   cout<<"\nEnter Number(data): ";
	   cin>>value;
	   if(!check1(value)){cout<<"Enter valid data\n";goto label1;}
   int val;
   stringstream sh(value);
   sh>>val;
   t1.insert(val);
  }
  else if(intchoice==3){
   cout<<"\nPreorder traversal of TBT\n";
   t1.preorder_traversal();
  }
  else if(intchoice==4){
   cout<<"\nInoder Traversal of TBT\n";
   t1.inorder_traversal();
  }
  else if(intchoice==0)break;
  else{
   cout<<"\nWrong choice";
  }
}

 return 0;
}
