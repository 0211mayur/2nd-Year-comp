#include <iostream>
#include<string>
#include<cstring>
#include<stdlib.h>
#include<limits>
using namespace std;

class Station
{
	//Name of station..
	string name;
	//Weight of the edge from source to dest...
	int cost;
	//link to next station...
	Station * next;
public:
	Station()			//constructor to initialize all the data member...
	{
		name = '\0';	//No station name..
		//Assign initial cost as zero....
		cost = 0;
		//isolated station...
		next = NULL;
	}
	//Vertex (Station) of Graph(Network) is created...
	friend class Network;
};

// Define the class which is collection of the Vertex(Station)..
class Network
{
	//Representation is done by using adjacency list...
	//creating the array of head pointer representing source vertex...
	Station *source[2000];
	int totalvertex;

public:
	//constructor to allocate the memory...
	Network(int n)
	{
		//source = new Station *[n+1];
		//n = > no of the vertex(Source) in graph(Network)...
		for(int i=0;i<n;i++)
		{
			source[i] = new Station;
			if(source[i] == NULL)
				cout<<"\nMEMORY IS NOT ALLOCATED...";
			cout<<"\nEnter the source Station name..";
			cin>>source[i]->name;
		}
		//Maintains the number of the vertex available in the graph..
		totalvertex = n;
	}
	//Creation of the node in the Graph and insert..
	void create(string ,string ,int);
	//insert the edge between the (u,v) u=>source , v=>destination
	void insert(Station *,Station *);
	//station number indicator..
	int Stationnumber(string);
	//Function to create the vertex in the graph..
	void Create_station();
	//Function for BFS traversal of the graph from given Station..
	void BFS(string, int visited[]);
	//Function for calculating the in-degree of the vertex....
	int Indegree(string name);
	//Function for calculating the out-degree of the vertex....
	int Outdegree(string name);
	//Function for deleting the edge...
	void Deletepath(string src, string dest);
	//Function for deleting the vertex...
	void Deletestation(string name);
};

void Network::create(string s,string t,int time)
{
	Station* dest = new Station;
	//If memory is not alloacated then...
	if(dest == NULL)
		cout<<"\nMemory is not allocated...";
	//if no exception the go for the insertion..
	else
	{
		dest->name = t;
		dest->cost = time;
		//catch the number associated with station..
		int j = Stationnumber(s);
		if(j != -1)
		{
			Station * src = source[j];
			//insert the edge...
			insert(src,dest);

		}
		else
		{
			cout<<"\nInvalid stationnames..";
		}
	}
}
int Network::Stationnumber(string x)
{
	//returns the station number associated with x..
	for(int i = 0;i<totalvertex;i++)
	{
		if(x == source[i]->name)
			return i;
	}
	return -1;
}

void Network::insert(Station * x, Station *y)
{
	//inserts the edge between the x and y...
	if(x->next == NULL)   //No vertex is present in list
	{
		x->next = y;
	}
	else
	{
		//If group of vertex present the traverse up to last..
		while(x->next)
			x = x->next;
		x->next = y;
	}
}

//Function to add vertex in it...
void Network::Create_station()
{
	//Accept the name for new station...
	string sname;
	cout<<"\nEnter the name for new Station..";
	cin>>sname;
	//Allocate the node for the staionname..
	source[totalvertex] = new Station;
	source[totalvertex]->name = sname;
	totalvertex++;
	cout<<"\nStaion is inserted in graph...\n\n";
}

//Function for BFS traversal of the Graph....

void Network::BFS(string s,  int visited[])
{
	string  Queue[20];
	int front = -1;
	int rear = 0;
	string sample;
	//indicate the current traversing vertex...
	int current = Stationnumber(s);
	Queue[rear++] = source[current]->name;
	visited[current] = 1;
	while(front!= rear)
	{
		sample = Queue[++front];
		cout<<sample<<"\t";

		for(Station * temp = source[Stationnumber(sample)];temp != NULL;temp = temp->next)
		{
			if(!visited[Stationnumber(temp->name)])
			{
				Queue[rear++] = temp->name;
				visited[Stationnumber(temp->name)] = 1;
			}
		}
	}

}

int Network::Outdegree(string name){
	int s = Stationnumber(name);
	if(s != -1){
		int count = 0;
		Station *ptr = source[s];
		ptr = ptr->next;
		while(ptr){
			count++;
		    ptr = ptr -> next;
		}
		return count;
	}
	return -1;
}

int Network::Indegree(string name){
	int count = 0;
	for(int i=0;i<totalvertex;i++){
		Station *ptr = source[i];
		ptr = ptr->next;
		while(ptr){
			if(ptr->name == name)
				count++;
			ptr = ptr -> next;
		}
	}
	return count;
}

void Network::Deletepath(string src,string dest){
	int number = Stationnumber(src);
	if(number != -1){
		Station *ptr = source[number];
		Station *temp = ptr;
		ptr = ptr -> next;
		while(ptr){
			if(ptr->name == dest){
				temp->next = ptr->next;
				delete ptr;
				break;
			}
			temp = ptr;
			ptr = ptr->next;
		}
		cout<<"\n\nEDGE IS DELETED...";
	}
	else
	{
		cout<<"\nSource station is not present...";
	}

}

void Network::Deletestation(string name){
	int s = Stationnumber(name);
	if(s == -1)
		return;
	else
	{
		Station *ptr;
		ptr = source[s];
		while(ptr){
			ptr = source[s]->next;
			Deletepath(ptr->name, name);
			source[s]->next = ptr->next;
			delete ptr;
		}
	}
}

int menu1(int x)
{
	enter:
	int choice;
	cout<<"\n\t\tSTATION NETWORK(directed graph)..\n";
	cout<<"\nENTER 1 for path insertion..";
	cout<<"\nENTER 2 for Station insertion...";
	cout<<"\nENTER 3 for Breadth first Traversal of the Network";
	if(x == 1){
		cout<<"\nENTER 4 for In-degree calculation";
		cout<<"\nENTER 5  for outdegree the program..";
	}
	else
		cout<<"\nEnter 4 for degree calulation";
	cout<<"\nENTER 6 for exit the program";
	cout<<"\nEnter 7 for path deletion";
	cout<<"\nEnter 8 for station deletion";
	cin>>choice;
	if(cin.fail())
	{
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
		goto enter;
	}
	return choice;
}
int main() {
	//Network N;
	int direction;
	cout<<"\nENTER 1 for directed graph";
	cout<<"\nENTER 2 for undirected graph";
	cin>>direction;
	int n;
vertex:
	cout<<"\nenter the number of the vertex in the graph..";
	cin>>n;
	if(cin.fail())
	{
		cin.clear();
		cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
		goto vertex;
	}
	Network N(n);    //Graph is created with n verices..
	while(1)
	{
	  int choice = menu1(direction);  //Choice selection..
	switch(choice)
	{
		case 1:
		{
			//enter of the edge...
			string source;
			string dest;
			int time;
			cout<<"\nEnter the staring and ending Station of path and fighttime..";
			cin>>source>>dest>>time;
			N.create(source,dest,time);
			if(direction == 2){
				N.create(dest,source,time);
			}
			cout<<"\nEdge is inserted...";
			break;
		}
		case 2:
		{
			//adding the vertex...
			N.Create_station();
			break;
		}
		case 3: //BFS traversal of the Graph...
		{

			cout<<"\nTraversal of the graph";
			//cin>>start;
			int visited[20];
			for (int i = 0;i<20;i++){
				visited[i] = 0;
			}

			cout<<"\n";
			N.BFS("Kolhapur",visited);
			break;
		}
		case 4: // indegree calculation of the graph..
		{
			string name;
			cin>>name;
			int result = N.Indegree(name);
			cout<<"\nindegree = "<<result;
			break;
		}
		case 6:
		{
			exit(0);
		}
		case 5:	//outdegree calculation of the graph..
		{
			string name;
			cin>>name;
			if(direction == 1)
				cout<<"\noutdegree ="<<N.Outdegree(name);
			else
				cout<<"degree ="<<N.Outdegree(name);
			break;
		}
		case 7://Deletion of the path..
		{
			string src,dest;
			cin>>src>>dest;
			N.Deletepath(src,dest);
			if(direction == 2)
				N.Deletepath(dest,src);
			break;
		}
		case 8: //Deletion of the station...
		{
			string name;
			cin>>name;
			N.Deletestation(name);
			break;
		}
	}
	}




}
