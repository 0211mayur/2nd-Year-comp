#include<iostream>
#include<cstdlib>
#include<stack>

using namespace std;

struct value
{
	float w,c;
	int r;
public:
	friend class obst;
};

class obst
{
	value** t;
	int n,*k;
	float *p,*q;
public:
	obst(int num)
{
		n=num;
		t=new value*[n+1];
		for(int i=0;i<=n;i++)
			t[i]=new value[n+1];
		k=new int[n];
		p=new float[n];
		q=new float[n+1];
}

	void set()//ensure that the sum of probabilities should be 1
	{
		cout<<"Enter values for keys"<<endl;
		for(int i=1;i<=n;i++)
			cin>>k[i];

		cout<<"Enter successful search probabilities"<<endl;
		for(int i=1;i<=n;i++)
			cin>>p[i];

		cout<<"Enter unsuccessful search probabilities"<<endl;
		for(int i=0;i<=n;i++)
			cin>>q[i];
	}

	void calculate()//Algorithm given in class with some modification
	{
		int i,j;

		for(i=0;i<n;i++)
		{
			t[i][i].w=q[i];
			t[i][i].r=0;
			t[i][i].c=0;

			t[i][i+1].w=q[i]+q[i+1]+p[i+1];
			t[i][i+1].r=i+1;
			t[i][i+1].c=q[i]+q[i+1]+p[i+1];
		}

		t[n][n].w=q[n];
		t[n][n].r=t[n][n].c=0;

		for(int m=2;m<=n;m++)
		{
			for(i=0;i<=n-m;i++)
			{
				j=i+m;

				t[i][j].w=t[i][j-1].w+p[j]+q[j];

				float min=10000;
				int ind;
				for(int k=i+1;k<=j;k++)
				{
					if((t[i][k-1].c+t[k][j].c)<min)
					{
						min=t[i][k-1].c+t[k][j].c;
						ind=k;
					}
				}

				t[i][j].c=t[i][j].w+min;
				t[i][j].r=ind;
			}
		}
	}

	void display()//Display funtion for the obst final tree
	{
		cout<<"Cost is "<<t[0][n].c<<endl;
		cout<<"Weight is "<<t[0][n].w<<endl;
		cout<<"Root is "<<t[0][n].r<<endl<<endl;

		cout<<"Preorder traversal of tree : "<<endl<<endl;
		print_tree(0,n);
	}

	void print_tree(int i,int j)//Alternative to inorder printing
	{
		if(i<j)
			cout<<k[t[i][j].r]<<"\t";
		else
			return;
		print_tree(i,t[i][j].r-1);
		print_tree(t[i][j].r,j);
	}

};

int main()
{
	int numkey;
	cout<<"Enter number of keys"<<endl;
	cin>>numkey;
	obst o(numkey);
	o.set();
	o.calculate();
	o.display();
	return 0;
}
